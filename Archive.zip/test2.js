

const data = ['12kg*12FR','10Kg*2PR']
const weight =[]
split(',')
const resultedSet = []
 => {
  setTypeValue: 'main', 'dropset ', 'warmup', 'subset'
     weightValue: 12,
     weightUnits: 'Kg',
     repsValue: 12,
     repType: 'FR',

}

function paras(string,index){


Logic (string ) =>  temp =  {setTypeValue: 'main',
weightValue: 12,
weightUnits: 'Kg',
repsValue: 12,
repType: 'FR',

}

if (resultedSet[index-1].weightValue > temp.weightValue)
 temp.setTypeValue:'dropset'
else{
 temp.setTypeValue:'subset'

}
Logic

}
resultedSet.push({//})
  return {}
}



paras('12kg*12FR')

data.map((item, index) => paras(item,index))