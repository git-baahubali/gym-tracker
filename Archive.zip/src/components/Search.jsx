import React from 'react'
import AddCircleIcon from '@mui/icons-material/AddCircle';
function Search() {
    return (
        <div className='flex justify-center items-center'>
            
            <button className="button"><AddCircleIcon /> </button>
        </div>
    )
}

export default Search