import React from 'react'

function NewSet() {
  return (
    ul>li*
  )
}

export default NewSet