

function DbManager() {
  return (
    <div>
        <form action="">
            
        </form>
    </div>
  )
}

export default DbManager