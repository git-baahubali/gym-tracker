
// import { NavLink } from 'react-router-dom'

function HomePage() {
    return (
        <div>
     HomePage
       
        </div>

    )
}

export default HomePage

import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div>
      <Button>Click me</Button>
    </div>
  )
}
