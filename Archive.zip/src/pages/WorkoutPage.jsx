import React from 'react'
import ExerciseSection from '../components/ExerciseSection'
import Search from '../components/Search'

function WorkoutPage() {
    return (
        <div>
            <div className="flex flex-col items-center justify-start">
                <ExerciseSection />
       
            </div>
            {/* <Search /> */}

        </div>
    )
}

export default WorkoutPage