// test.js

// const temp = {
//     'setType': "Main",
//     'weight': 12,
//     'weightUnits': "Kg",
//     'reps': 8,
//     'repType': "FR"
//   }

//   console.log(temp);

//   const temp2 = {...temp , ['repType']:"PR"}

//   console.log(temp2);



