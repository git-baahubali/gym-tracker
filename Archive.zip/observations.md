#order of application building without plan
1. define router
2. make pages
3. make router work
4. build homepage
5. make components
6. make pages with state
7. persist data with useEffect & db
8. 