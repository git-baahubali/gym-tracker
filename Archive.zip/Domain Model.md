### set 
- id unique number
- weight number
- units picklist
- reps number
- repType picklsit
- time_under_tension number
- rest number
- date time date

### exercise_List
- id unique number

### exercise_Section
- id unique number
- exercise_name - id from exercise_list
- sets array of set ids
- 

### Routine
- id unique number
- routines array of ids of other routines

